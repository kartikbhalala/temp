***RadianceMiner-V4.0.0***

1, fixed a bug when mining with multiple GPUs
2, log is now clearer
3, lower the rejection rate
4, simplify the operation by allowing automatic checking for 8G, 1080ti and 2080ti cards